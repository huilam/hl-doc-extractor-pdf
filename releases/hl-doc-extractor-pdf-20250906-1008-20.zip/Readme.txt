run "./PDFExtractor.sh" will extract the sample PDF file in test/ 
